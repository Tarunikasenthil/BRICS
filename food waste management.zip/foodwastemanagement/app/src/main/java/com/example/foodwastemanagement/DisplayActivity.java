package com.example.foodwastemanagement;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class DisplayActivity extends AppCompatActivity {

    @SuppressLint({"SetTextI18n", "QueryPermissionsNeeded"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);


        EditText uname = (EditText) findViewById(R.id.etname);
        EditText fname = (EditText) findViewById(R.id.etfoodname);
        EditText quantity = (EditText) findViewById(R.id.etquantity);
        EditText number = (EditText) findViewById(R.id.etnum);

        Intent i = getIntent();

        String name = i.getStringExtra("name");
        String food = i.getStringExtra("food");
        String quant = i.getStringExtra("quant");
        String num = i.getStringExtra("num");
        double x =i.getDoubleExtra("lat",0);
        double y =i.getDoubleExtra("lng",0);

        uname.setText("Donor Name- "+name);
        fname.setText("Food Name- "+food);
        quantity.setText("Food Quantity- "+quant);
        number.setText("Donor Number- "+num);

        uname.setEnabled(false);
        fname.setEnabled(false);
        quantity.setEnabled(false);
        number.setEnabled(false);

        final String address = "geo:"+ x +","+ y;

        Button btn = (Button) findViewById(R.id.btnloc);

        btn.setOnClickListener(view -> {

            Uri gmmIntentUri = Uri.parse(address);
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            if (mapIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(mapIntent);
            }

                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(address));
                startActivity(intent);

        });

    }
}